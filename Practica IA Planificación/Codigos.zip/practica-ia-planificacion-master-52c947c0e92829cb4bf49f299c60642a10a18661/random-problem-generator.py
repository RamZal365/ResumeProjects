import random

def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.

def write_file(n_contenido, n_dias, predecesores, paralelos, min_contenido, visionado, extension):

    f = open("redflix_random.pddl", "w")

    f.write("(define (problem redflix-aleatorio)\n")
    f.write("\t(:domain redflix)\n")
    f.write("\t(:objects ")
    for i in range(n_contenido):
        f.write("s" + str(i) + " ")
    f.write("- contenido\n")
    f.write("\t")
    for i in range(n_dias):
        f.write("d" + str(i) + " ")
    f.write("- dia)\n\n")

    f.write("\t(:init\n\n")
    for i in range(n_dias - 1):
        f.write("\t\t(antes d"+str(i)+" d"+str(i+1)+")\n")
    f.write("\n")
    for i in range(n_dias):
        for j in range(i+1, n_dias):
            f.write("\t\t(anterior d"+str(i)+" d"+str(j)+")\n")
    f.write("\n")
    for i in range(n_contenido):
        curr_predecesores = predecesores.get(i, [])
        for j in curr_predecesores:
            f.write("\t\t(predecesor s"+str(i)+" s"+str(j)+")\n")
    f.write("\n")
    for i in range(n_contenido):
        curr_paralelos = paralelos.get(i, [])
        for j in curr_paralelos:
            f.write("\t\t(paralelo s"+str(i)+" s"+str(j)+")\n")
    f.write("\n")
    for i in visionado:
        f.write("\t\t(visionado s"+str(i)+")\n")
    f.write("\n")

    if extension == 3:
        for i in range(n_dias):
            f.write("\t\t(= (contenidosDia d"+str(i)+") 0)\n")

    if extension == 4:
        for i in range(n_contenido):
            f.write("\t\t(= (minContenido s"+str(i)+") "+str(min_contenido[i])+")\n")
        f.write("\n")

        for i in range(n_dias):
            f.write("\t\t(= (minLibresDia d"+str(i)+") 200)\n")

    f.write("\t)\n\n")

    f.write("\t(:goal (not (exists (?s ?s1 - contenido) (and (visionado ?s) (not (visto ?s))) ) ) )\n")

    f.write(")")



if __name__ == '__main__':
    ext = 0
    while ext != 3 and ext != 4:
        print("¿Usando la extensión 3 o 4?")
        ext = int(input())
        if ext != 3 and ext != 4:
            print("Introduzca solo el numero, por favor.")

    n_contenido = random.randint(8,14)
    n_dias = random.randint(3, 7)
    n_visionado = random.randint(3, 6)
    predecesores = {}
    paralelos = {}
    min_contenido = []
    visionado = []
    for i in range(n_contenido):
        # Asignamos contenido predecesor
        n_predecesores = random.randint(0, 1)
        if n_predecesores > 0:
            predecesor = random.randrange(n_contenido)
            if predecesor not in predecesores.get(i, []) and i not in predecesores.get(predecesor, []) \
                    and predecesor not in paralelos.get(i, []) and i not in paralelos.get(predecesor, []) \
                    and i != predecesor:
                predecesores[i] = predecesores.get(i, [])
                predecesores[i].append(predecesor)

        #Asignamos contenido paralelo
        n_paralelos = random.randint(0, 1)
        for p in range(n_paralelos):
            paralelo = random.randrange(n_contenido)
            if paralelo not in paralelos.get(i, []) and paralelo not in predecesores.get(i, []) \
                    and i not in predecesores.get(paralelo, []) and i not in paralelos.get(paralelo, []) \
                    and i != paralelo:
                paralelos[i] = paralelos.get(i, [])
                paralelos[i].append(paralelo)

        for j in range(n_contenido):
            min_contenido.append(random.randint(50, 110))

    for i in range(n_visionado):
        curr_visionado = random.randrange(n_contenido)
        if curr_visionado not in visionado:
            visionado.append(curr_visionado)

    write_file(n_contenido, n_dias, predecesores, paralelos, min_contenido, visionado, ext)

