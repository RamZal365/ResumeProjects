export CLASSPATH=".:../lib/AIMA.jar:../lib/Azamon.jar"
rm -f Main.class ./IA/Azamon/*.class
javac -d . *.java
javac Main.java
#java Main "$@" -p 100 -o 1.2 -s 1234 -i 0
#java Main "$@" -p 100 -o 1.2 -s 1234 -i 1 -c 6
#java Main "$@" --help
